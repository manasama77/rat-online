<script>
	$(document).ready(function(){
		$('#tanggal_lahir').datepicker({
			format: 'dd-mm-yyyy',
			autoclose: true
		});
	});
</script>