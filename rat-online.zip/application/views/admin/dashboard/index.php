<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>Dashboard </h1>
</section>

<!-- Main content -->
<section class="content">

	<div class="row">

		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-cubes"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Produk</span>
					<span class="info-box-number">0</span>
				</div>
			</div>
		</div>

	</div>

</section>
<!-- /.content -->