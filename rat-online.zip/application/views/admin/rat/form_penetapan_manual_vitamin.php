<script>
	$(document).ready(function(){

		$('#rat_mulai').datepicker({
			format: 'dd-mm-yyyy',
			autoclose: true
		});

		$('#rat_akhir').datepicker({
			format: 'dd-mm-yyyy',
			autoclose: true
		});

		$('#polling_mulai').datepicker({
			format: 'dd-mm-yyyy',
			autoclose: true
		});

		$('#polling_akhir').datepicker({
			format: 'dd-mm-yyyy',
			autoclose: true
		});

	});
</script>